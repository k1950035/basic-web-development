import "./App.css";
import BackgroundFetcher from "./components/BackgroundFetcher.tsx";
import { useState } from "react";

function App() {
  const [petName, setPetName] = useState("강아지");
  return (
    <div className="flex flex-col w-[400px] h-[500px] bg-green-300">
      <div className="flex w-full h-[50px] bg-blue-300 items-center justify-center">
        <div className="font font-bold text-2xl">{petName} 키우기</div>
      </div>
      <BackgroundFetcher />
    </div>
  );
}

export default App;

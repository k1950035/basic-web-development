import React, { useState, useEffect, useCallback } from "react";

// ====================================================================
// Constants and Utilities (상수 및 유틸리티)
// ====================================================================

// Unsplash API Access Key (사용자의 키로 대체됨)
const ACCESS_KEY = "OrdMtk_W9TS7mbDu81buhMo70Sq3S-L43MLD6xw9mU8";

// LocalStorage Keys
const LS_KEY_COINS = "petExtensionCoins";
const LS_KEY_SCALE = "petExtensionScale";

// Unsplash Credit Icon (인라인 SVG)
const UnsplashIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 16 16"
    className="w-4 h-4 text-white drop-shadow-sm inline-block mr-1"
    fill="currentColor"
    aria-hidden="true"
  >
    {/* Simple pixel-style camera icon for visual aesthetics */}
    <rect x="2" y="5" width="12" height="8" rx="1" ry="1" />
    <circle cx="8" cy="9" r="2" fill="white" />
    <path d="M4 5V3h8v2z" fill="currentColor" />
  </svg>
);

// ====================================================================
// Main Extension Popup Component (메인 확장 프로그램 팝업 컴포넌트)
// ====================================================================

export default function App() {
  // State for UI and API data
  const [backgroundImageUrl, setBackgroundImageUrl] = useState("");
  const [photoCreditText, setPhotoCreditText] = useState("");
  const [photoLink, setPhotoLink] = useState("");
  const [loadingBackground, setLoadingBackground] = useState(false);
  const [message, setMessage] = useState(""); // User message display state

  // Game States (localStorage-synced)
  const [coins, setCoins] = useState(0);
  const [petScale, setPetScale] = useState(1.0); // Pet size state (1.0 is default)
  const PET_SCALE_COST = 10; // Coin cost to increase size

  // --- I. LocalStorage Sync ---

  // Load initial state from localStorage on mount
  useEffect(() => {
    // Load coins
    const storedCoins = localStorage.getItem(LS_KEY_COINS);
    if (storedCoins !== null) {
      setCoins(parseInt(storedCoins, 10));
    }

    // Load pet scale
    const storedScale = localStorage.getItem(LS_KEY_SCALE);
    if (storedScale !== null) {
      setPetScale(parseFloat(storedScale));
    }
  }, []);

  // Save state to localStorage whenever coins or scale changes
  useEffect(() => {
    localStorage.setItem(LS_KEY_COINS, coins.toString());
  }, [coins]);

  useEffect(() => {
    localStorage.setItem(LS_KEY_SCALE, petScale.toString());
  }, [petScale]);

  // --- II. API Fetching ---

  const fetchRandomBackground = useCallback(async () => {
    setLoadingBackground(true);
    setMessage("");

    // Optimized query for pixel art look
    const query = "retro%20pixel%20art%20game%20background";
    const url = `https://api.unsplash.com/photos/random?client_id=${ACCESS_KEY}&query=${query}&orientation=landscape`;

    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();

      const imageUrl = data.urls.regular;

      setBackgroundImageUrl(imageUrl);
      setPhotoCreditText(`Photo by ${data.user.name}`);
      // Unsplash policy compliance: include referral link
      setPhotoLink(
        `${data.links.html}?utm_source=pet-extension&utm_medium=referral`
      );
    } catch (error) {
      console.error("Unsplash API call failed:", error); // Unsplash API 호출 실패
      setBackgroundImageUrl("");
      setPhotoCreditText("배경 로드 실패. 다시 시도해 주세요.");
      setPhotoLink("");
    } finally {
      setLoadingBackground(false);
    }
  }, []);

  useEffect(() => {
    fetchRandomBackground();
  }, [fetchRandomBackground]);

  // --- III. Game Logic ---

  // Function to increase coins when pet is clicked
  const increaseCoin = useCallback((amount = 1) => {
    setCoins((prevCoins) => prevCoins + amount);
    // Flash message for coin acquisition
    setMessage((prev) =>
      prev === "코인 획득!" ? "코인 획득!!" : "코인 획득!"
    );
    setTimeout(() => setMessage(""), 1000);
  }, []);

  // Function to change pet size
  const updatePetSize = useCallback(
    (delta) => {
      // Limits pet size between 0.5 and 2.0
      const newScale = Math.max(0.5, Math.min(2.0, petScale + delta));

      if (delta > 0) {
        // Scale up: requires coin payment
        if (coins >= PET_SCALE_COST) {
          setCoins((prevCoins) => prevCoins - PET_SCALE_COST);
          setPetScale(newScale);
          setMessage("펫 크기 증가!🎉");
        } else {
          setMessage(
            `코인이 부족해요! ${PET_SCALE_COST - coins}C 더 모아야 해요.`
          );
        }
      } else {
        // Scale down: free of charge
        setPetScale(newScale);
        setMessage("펫 크기 감소!");
      }
      setTimeout(() => setMessage(""), 1500); // Clear message after 1.5s
    },
    [coins, petScale]
  );

  // --- IV. Styles and Rendering (Tailwind CSS) ---

  // Tailwind classes for the main container
  const containerClasses = `
    flex flex-col justify-between items-center p-4 rounded-xl shadow-2xl 
    bg-[#e6f7ff] text-black transition-all duration-300 overflow-hidden
  `;

  // Dynamic inline style for background image
  const dynamicStyle = {
    backgroundImage: backgroundImageUrl ? `url(${backgroundImageUrl})` : "none",
    backgroundSize: "cover",
    backgroundPosition: "center",
    minHeight: "400px",
    minWidth: "300px",
  };

  // Tailwind classes for shadowed white text
  const textShadowClasses = "text-white drop-shadow-md font-['Inter']";

  return (
    <div className={containerClasses} style={dynamicStyle}>
      {/* User Message Area (코인 획득, 부족 등 메시지) */}
      <div className="h-8 mb-2 w-full text-center">
        {message && (
          <p className="bg-yellow-400 text-gray-800 text-sm font-semibold py-1 px-3 rounded-full inline-block shadow-lg animate-pulse">
            {message}
          </p>
        )}
      </div>

      {/* Main Content Area (펫 & 코인) */}
      <div className="flex-grow flex flex-col justify-center items-center w-full">
        {loadingBackground && (
          <p className="text-lg font-bold text-gray-800 p-4 bg-white/70 rounded-lg">
            배경 로딩 중...
          </p>
        )}

        {!loadingBackground && backgroundImageUrl ? (
          <>
            <h2 className={`text-2xl font-bold ${textShadowClasses}`}>
              내 귀여운 펫!
            </h2>

            {/* Pet Element: Clickable for coins, scale adjusted by state */}
            <div
              className="transition-transform duration-300 cursor-pointer p-4 hover:scale-105"
              style={{ transform: `scale(${petScale})` }}
              onClick={() => increaseCoin(1)}
              title="클릭하여 코인 획득"
            >
              {/* NOTE: Replace this emoji with your custom pet asset/sprite */}
              <span className="text-7xl" role="img" aria-label="pet">
                🐶
              </span>
            </div>

            <p
              className={`text-3xl font-extrabold mt-4 ${textShadowClasses} bg-black/30 rounded-lg px-3 py-1`}
            >
              💰 코인: {coins}
            </p>
          </>
        ) : (
          // Error State Message
          <p className="text-red-600 font-bold text-center p-4 bg-white/80 rounded-lg">
            {photoCreditText}
          </p>
        )}
      </div>

      {/* Controls and Credits Section (조작 버튼 및 크레딧) */}
      <div className="w-full flex flex-col items-center space-y-3">
        {/* Pet Size Control Buttons */}
        <div className="flex space-x-2 p-2 bg-white/30 rounded-xl shadow-inner">
          <button
            onClick={() => updatePetSize(-0.1)}
            disabled={petScale <= 0.5}
            className="px-4 py-2 text-sm bg-indigo-500 text-white font-semibold rounded-full hover:bg-indigo-600 transition duration-150 shadow-md disabled:bg-gray-400"
          >
            크기 줄이기
          </button>
          <button
            onClick={() => updatePetSize(0.1)}
            disabled={coins < PET_SCALE_COST || petScale >= 2.0}
            className={`px-4 py-2 text-sm text-white font-semibold rounded-full transition duration-150 shadow-md ${
              coins >= PET_SCALE_COST && petScale < 2.0
                ? "bg-pink-500 hover:bg-pink-600"
                : "bg-gray-400 cursor-not-allowed"
            }`}
          >
            크기 키우기 ({PET_SCALE_COST}C)
          </button>
        </div>

        {/* Background Button */}
        <button
          onClick={fetchRandomBackground}
          disabled={loadingBackground}
          className="w-full py-2 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600 transition duration-150 shadow-lg disabled:bg-gray-400"
        >
          {loadingBackground ? "배경 찾는 중..." : "새로운 배경 뽑기"}
        </button>

        {/* Unsplash Credit Link */}
        {photoCreditText && photoLink && (
          <p className="text-xs text-white opacity-90 text-center px-1">
            <UnsplashIcon />
            <a
              href={photoLink}
              target="_blank"
              rel="noopener noreferrer"
              className="underline hover:text-yellow-300 transition"
            >
              {photoCreditText}
            </a>{" "}
            on Unsplash
          </p>
        )}
      </div>
    </div>
  );
}
